﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.Net;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;

namespace ConsoleApp2
{
    public class Scraper
    {
        static string urlRankings = "https://rankings.the-elite.net";
        static string urlHistory = "https://rankings.the-elite.net/history/2017/10";
        static string urlUserCSS = "https://rankings.the-elite.net/css/users.1510033127.css";

        Game GE = new Game();
        Game PD = new Game();

        public void GenProof()
        {
            string UserColors = "";
            string UsersPRPage = "";


            //Load the HTML page.
            HtmlWeb page = new HtmlWeb();
            HtmlDocument doc = page.Load(urlHistory);

            //Load the CSS file for user colors so we can link them.
            using (WebClient client = new WebClient())
            {
                UserColors = client.DownloadString(urlUserCSS);
            }


            var p = doc.DocumentNode.SelectSingleNode("//table");
            for (int j = 1; j < p.SelectNodes(".//tr").Count; j++)
            {
                //Select the entire row.
                var rec = p.SelectNodes(".//tr")[j];
                var points = rec.ChildNodes[9].InnerText;

                //If the time is worth less than 60 points, we don't need to proofcall it.
                if (points == "Unknown" || int.Parse(points) < 60)
                    continue;

                var date = rec.ChildNodes[1].InnerText;
                var time = rec.ChildNodes[5].InnerText;

                //This truly is a 140+ IQ line written by me. It trims the extra whitespace crap added to a time. 
                //The last one makes up for a missing space (untied!) that shows up on untieds.
                time = Regex.Replace(time, @"\s{2,}", "").Trim().Replace("(", " (");
                var levelname = time;
                time = time.Replace("-", "");

                //Get the name. But the name doesn't tell me it's a real name or alias.
                //So I check based on the level name.
                var name = rec.ChildNodes[3].InnerText; 

                //Get the hex color of the user from the CSS file.
                var id = Regex.Match(rec.ChildNodes[3].InnerHtml, "u(\\d+)").Groups[1].Value;
                var color = Regex.Match(UserColors, "u" + id + "(?!\\d).*?{color:(#.*?)}").Groups[1].Value;              

                //Just figure out some generic properties of the time.
                var hasVideo = rec.ChildNodes[7].InnerText.Length != 0 ? true : false;
                var isWR = int.Parse(points) == 100 ? true : false;
                var isUntied = isWR && time.Contains("untied") ? true : false;

                time = time.Replace("(untied!)", "").Trim();
                var link = "";

                if (hasVideo)
                {
                    var URL = string.Concat(urlRankings, Regex.Match(rec.ChildNodes[5].InnerHtml, "href=\"(.*?)\"").Groups[1]);
                    using (WebClient client = new WebClient())
                    {
                        UsersPRPage = client.DownloadString(URL);
                        link = Regex.Match(UsersPRPage, "<a href=\"(.*)\">(Watch on .*|Download video)</a>").Groups[1].Value;
                        //Console.WriteLine(link);
                    }
                }

                //Console.WriteLine(link);
                //continue;

                Record r = new Record(date, name, time, levelname, hasVideo, isWR, isUntied, int.Parse(points), link);

                if (LevelProps.IsGELevel(levelname))
                    AppendRecord(GE, id, name, color, levelname, r);
                else
                    AppendRecord(PD, id, name, color, levelname, r);
            }

            //return;
            GenerateHTML(PD);
        }

        public void AppendRecord(Game Game, string id, string name, string color, string levelname, Record r)
        {
            //If the player already exists, then don't add them.
            int index = Game.Players.FindIndex(a => a.ID == id);
            if (index == -1)
                Game.Players.Add(new Player(id, name, color));

            index = Game.Players.FindIndex(a => a.ID == id);

            //Check if the player has improved a time on the level.
            if (Game.Players[index].Records.FindIndex(a => a.LevelName == LevelProps.LevelName(levelname)) == -1)
            {
                Game.Players[index].Records.Add(r);

                if (r.IsWR)
                {
                    Game.Players[index].WRCount++;
                    Game.TotalWRs++;
                }

                if (r.IsUntied)
                {
                    Game.Players[index].UntiedCount++;
                    Game.TotalUntieds++;
                }
            }
        }

        private void GenerateHTML(Game game)
        {
            StringBuilder s = new StringBuilder();
            s.Append(@"Times that say [color=red][size=10pt][b]NEEDS PROOF[/b][/size][/color] need videos up by December 1st or they will be backrolled.
Also included are the point values, and whether the time was a [color=yellow]TWR[/color] or [color=orange]UWR[/color] when listed time was achieved.");

            s.AppendLine();
            s.AppendLine();

            foreach (Player player in game.Players)
            {
                //Console.WriteLine(player.HexColor);
                //continue;

                s.AppendLine($@"[color={player.HexColor}][size=10pt][b]{player.Name}[/b][/size][/color]");

                foreach (Record record in player.Records)
                {
                    string time = "";

                    if (record.HasVideo)
                        time = $@"[url={record.VideoLink}]{record.Time}[/url]";
                    else
                        time = $"{record.Time}";

                    string style = record.IsUntied ? $"[color=orange]{time}[/color] (Untied!) -" :
                                   record.IsWR     ? $"[color=yellow]{time}[/color] (TWR) -"     : $@"{time} ({record.Points} points) -";

                    string isProven = record.HasVideo ? "[color=limegreen][size=10pt][b]PROVEN[/b][/size][/color]" :
                                                        "[color=red][size=10pt][b]NEEDS PROOF[/b][/size][/color]";

                    s.AppendLine(style + " " + isProven);
                }
                s.AppendLine();
            }

            s.AppendLine($@"{game.TotalWRs} [color=yellow]TWRs[/color] achieved this month!");
            s.Append($@"{game.TotalUntieds} [color=orange]UWRs[/color] achieved this month!");

            //for (int i = 0; i < game.Players.Count; i++)
            //{
            //    s.Append($@"[color={game.Players[i].HexColor}][size=10pt][b]{game.Players[i].Name}[/b][/size][/color]\n");
            //    for (int j = 0; j < players[i].Records.PD.Count; j++)
            //        Console.WriteLine(players[i].Records.PD[j].Time);

            //    Console.WriteLine();
            //}

            File.WriteAllText(@"C:\Users\ace\source\repos\ConsoleApp2\ConsoleApp2\bin\Debug\mate.txt", s.ToString());
            //Console.WriteLine(s);

            //            [color=#7ddb8c][size=10pt][b]Ryan White[/b][/size][/color]
            //Silo 00 Agent 1:23 (94 points) - [color=limegreen]
            //        [size=10pt]
            //        [b]
            //        PROVEN[/ b][/ size][/ color]
            //Silo 00 Agent 1:26 - [color=purple] [b] [glow=white,2,300] NTSC-J UWR[/ glow][/b] [/color] - [color=limegreen] [size=10pt] [b] PROVEN[/ b][/ size][/ color]
        }
    }
}
